using System;
using System.Collections.Generic;

namespace KfkaEstruturaDados
{
    /// Objetivo: simular a paginação de alunos utilizando uma List<Aluno>
    /// populada a partir de um banco de dados relacional (SQLite).
    ///
    /// O Program.cs apenas ORQUESTRA o fluxo:
    ///   1) garante o banco e os dados;
    ///   2) carrega tudo para a lista em memória;
    ///   3) executa a paginação sobre a lista.
    class Program
    {
        private const int TamanhoPagina = 5;

        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // 1) Repositório: cria o arquivo alunos.db e a tabela, se ainda não existirem.
            AlunoDB repositorio = new AlunoDB("alunos.db");

            // 2) Popula o banco apenas na primeira execução.
            if (repositorio.ContarRegistros() == 0)
            {
                Console.WriteLine("Banco vazio. Inserindo dados fictícios...");
                PopularBanco(repositorio);
            }

            // 3) Carrega os dados do banco para a estrutura de dados em memória.
            //    A partir daqui, NENHUMA consulta adicional é feita ao banco:
            //    toda a paginação acontece sobre a List<Aluno>.
            List<Aluno> alunos = repositorio.ObterTodos();

            Console.WriteLine($"Total de alunos carregados na lista (Count): {alunos.Count}");
            Console.WriteLine("Pressione ENTER para iniciar a listagem paginada...");
            Console.ReadLine();

            ExecutarPaginacao(alunos);
        }

        /// Laço principal da paginação: exibe uma página por vez e lê o comando do usuário.
        static void ExecutarPaginacao(List<Aluno> alunos)
        {
            if (alunos.Count == 0)
            {
                Console.WriteLine("Não há alunos cadastrados.");
                return;
            }

            // Cálculo do total de páginas (divisão inteira arredondada para cima).
            int totalPaginas = (alunos.Count + TamanhoPagina - 1) / TamanhoPagina;
            int paginaAtual = 1;
            bool continuar = true;

            while (continuar)
            {
                Console.Clear();
                ExibirPagina(alunos, paginaAtual, totalPaginas);

                Console.WriteLine();
                Console.WriteLine("[P] Próxima  [A] Anterior  [I] Ir para página  [B] Buscar matrícula  [S] Sair");
                Console.Write("Opção: ");
                string opcao = (Console.ReadLine() ?? "").Trim().ToUpper();

                switch (opcao)
                {
                    case "P":
                        if (paginaAtual < totalPaginas) paginaAtual++;
                        else AvisarLimite("Você já está na última página.");
                        break;

                    case "A":
                        if (paginaAtual > 1) paginaAtual--;
                        else AvisarLimite("Você já está na primeira página.");
                        break;

                    case "I":
                        paginaAtual = LerNumeroPagina(totalPaginas, paginaAtual);
                        break;

                    case "B":
                        BuscarAluno(alunos);
                        break;

                    case "S":
                        continuar = false;
                        break;

                    default:
                        AvisarLimite("Opção inválida.");
                        break;
                }
            }

            Console.WriteLine("Encerrando a aplicação.");
        }

        /// Exibe apenas o subconjunto de alunos correspondente à página solicitada.
        static void ExibirPagina(List<Aluno> alunos, int pagina, int totalPaginas)
        {
            int indiceInicial = (pagina - 1) * TamanhoPagina;
            int indiceFinal = Math.Min(indiceInicial + TamanhoPagina, alunos.Count);

            Console.WriteLine("=== KFKA - LISTAGEM DE ALUNOS ===");
            Console.WriteLine($"Página {pagina} de {totalPaginas}  |  " +
                              $"Registros {indiceInicial + 1}-{indiceFinal} de {alunos.Count}");
            Console.WriteLine();

            Aluno.ExibirCabecalho();

            // Acesso por índice na List.
            for (int i = indiceInicial; i < indiceFinal; i++)
            {
                alunos[i].ExibirDados();
            }
        }

        /// Busca sequencial sobre a lista em memória.
        static void BuscarAluno(List<Aluno> alunos)
        {
            Console.Write("Digite a matrícula: ");
            if (!int.TryParse(Console.ReadLine(), out int matricula))
            {
                AvisarLimite("Matrícula inválida.");
                return;
            }

            Aluno encontrado = BuscarPorMatricula(alunos, matricula);

            Console.WriteLine();
            if (encontrado != null)
            {
                Console.WriteLine("Aluno localizado:");
                Aluno.ExibirCabecalho();
                encontrado.ExibirDados();
            }
            else
            {
                Console.WriteLine("Aluno não encontrado na lista.");
            }

            Console.WriteLine();
            Console.Write("Pressione ENTER para voltar...");
            Console.ReadLine();
        }

        /// Busca sequencial customizada: percorre a lista até encontrar a matrícula.
        static Aluno BuscarPorMatricula(List<Aluno> lista, int matricula)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                if (lista[i].Matricula == matricula)
                {
                    return lista[i]; // Retorna a referência do objeto encontrado
                }
            }
            return null;
        }

        static int LerNumeroPagina(int totalPaginas, int paginaAtual)
        {
            Console.Write($"Informe o número da página (1 a {totalPaginas}): ");
            if (int.TryParse(Console.ReadLine(), out int destino) &&
                destino >= 1 && destino <= totalPaginas)
            {
                return destino;
            }

            AvisarLimite("Página inválida.");
            return paginaAtual;
        }

        static void AvisarLimite(string mensagem)
        {
            Console.WriteLine();
            Console.WriteLine(mensagem);
            Console.Write("Pressione ENTER para continuar...");
            Console.ReadLine();
        }

        /// Insere dados fictícios no banco (exigência do projeto: dados fictícios
        /// para demonstração). Usa InserirOuAtualizar para ser reexecutável sem erro.
        static void PopularBanco(AlunoDB repositorio)
        {
            string[] nomes =
            {
                "Ana Beatriz Ferreira", "Bruno Almeida Costa", "Carlos Eduardo Lima",
                "Daniela Souza Martins", "Eduardo Nunes Ribeiro", "Fernanda Oliveira Dias",
                "Gabriel Santos Rocha", "Helena Carvalho Pinto", "Igor Mendes Barbosa",
                "Julia Ramos Teixeira", "Kevin Araujo Moreira", "Larissa Gomes Pereira",
                "Marcelo Cardoso Freitas", "Natalia Barros Azevedo", "Otavio Correia Lopes",
                "Paula Fernandes Machado", "Rafael Duarte Monteiro", "Sabrina Melo Cunha",
                "Thiago Vieira Antunes", "Vitoria Castro Siqueira", "William Pires Nogueira",
                "Yasmin Tavares Fonseca", "Arthur Bastos Miranda", "Beatriz Campos Rezende"
            };

            string[] turmas = { "6A", "6B", "7A", "7B" };
            string[] series = { "6º ano", "6º ano", "7º ano", "7º ano" };

            string[] responsaveis =
            {
                "Marcos Ferreira", "Patricia Costa", "Sandra Lima", "Roberto Martins",
                "Claudia Ribeiro", "Antonio Dias", "Silvia Rocha", "Paulo Pinto",
                "Regina Barbosa", "Fernando Teixeira", "Monica Moreira", "Jorge Pereira",
                "Adriana Freitas", "Luiz Azevedo", "Carla Lopes", "Sergio Machado",
                "Vanessa Monteiro", "Ricardo Cunha", "Simone Antunes", "Andre Siqueira",
                "Debora Nogueira", "Gustavo Fonseca", "Elaine Miranda", "Marcio Rezende"
            };

            for (int i = 0; i < nomes.Length; i++)
            {
                int indiceTurma = i % turmas.Length;

                Aluno aluno = new Aluno(
                    1001 + i,
                    nomes[i],
                    turmas[indiceTurma],
                    series[indiceTurma],
                    responsaveis[i]
                );

                repositorio.InserirOuAtualizar(aluno);
            }

            Console.WriteLine($"{nomes.Length} alunos inseridos com sucesso.");
        }
    }
}
