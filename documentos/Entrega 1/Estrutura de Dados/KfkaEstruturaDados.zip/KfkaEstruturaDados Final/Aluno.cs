using System;

namespace KfkaEstruturaDados
{
    /// TAD (Tipo Abstrato de Dados) que representa um aluno do Ensino Fundamental
    /// no contexto da plataforma KFKA.
    public class Aluno
    {
        public int Matricula { get; set; }
        public string Nome { get; set; }
        public string Turma { get; set; }
        public string Serie { get; set; }
        public string Responsavel { get; set; }

        public Aluno(int matricula, string nome, string turma, string serie, string responsavel)
        {
            Matricula = matricula;
            Nome = nome;
            Turma = turma;
            Serie = serie;
            Responsavel = responsavel;
        }

        /// Exibe os dados do aluno formatados em colunas para a listagem paginada.
        public void ExibirDados()
        {
            Console.WriteLine(
                $"{Matricula,-10} {Nome,-28} {Turma,-8} {Serie,-10} {Responsavel,-28}");
        }

        public static void ExibirCabecalho()
        {
            Console.WriteLine(
                $"{"MATRÍCULA",-10} {"NOME",-28} {"TURMA",-8} {"SÉRIE",-10} {"RESPONSÁVEL",-28}");
            Console.WriteLine(new string('-', 88));
        }
    }
}
