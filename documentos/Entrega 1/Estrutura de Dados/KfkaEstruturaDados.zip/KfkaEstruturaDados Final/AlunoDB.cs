using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;

namespace KfkaEstruturaDados
{
    /// Classe de acesso a dados (repositório) do aluno.
    /// Centraliza a connection string, encapsula o SQL e expõe métodos.
    public class AlunoDB
    {
        private readonly string _connectionString;

        // MÉTODO 1 — Construtor: monta a connection string e garante a tabela.
        public AlunoDB(string caminhoBanco)
        {
            _connectionString = $"Data Source={caminhoBanco}";
            CriarTabelaSeNaoExistir();
        }

        // MÉTODO 2 — DDL idempotente: cria a tabela apenas se ela ainda não existir.
        private void CriarTabelaSeNaoExistir()
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                CREATE TABLE IF NOT EXISTS Aluno (
                    Matricula   INTEGER NOT NULL PRIMARY KEY,
                    Nome        TEXT    NOT NULL,
                    Turma       TEXT    NOT NULL,
                    Serie       TEXT    NOT NULL,
                    Responsavel TEXT    NOT NULL
                );
            ";
            comando.ExecuteNonQuery();
        }

        // MÉTODO 3 — INSERT com parâmetros (nunca concatenar SQL).
        public void Inserir(Aluno item)
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                INSERT INTO Aluno (Matricula, Nome, Turma, Serie, Responsavel)
                VALUES (@matricula, @nome, @turma, @serie, @responsavel);
            ";
            comando.Parameters.AddWithValue("@matricula", item.Matricula);
            comando.Parameters.AddWithValue("@nome", item.Nome);
            comando.Parameters.AddWithValue("@turma", item.Turma);
            comando.Parameters.AddWithValue("@serie", item.Serie);
            comando.Parameters.AddWithValue("@responsavel", item.Responsavel);
            comando.ExecuteNonQuery();
        }

        // MÉTODO 4 — UPDATE localizando o registro pela chave primária.
        public void Atualizar(Aluno item)
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                UPDATE Aluno
                   SET Nome = @nome,
                       Turma = @turma,
                       Serie = @serie,
                       Responsavel = @responsavel
                 WHERE Matricula = @matricula;
            ";
            comando.Parameters.AddWithValue("@matricula", item.Matricula);
            comando.Parameters.AddWithValue("@nome", item.Nome);
            comando.Parameters.AddWithValue("@turma", item.Turma);
            comando.Parameters.AddWithValue("@serie", item.Serie);
            comando.Parameters.AddWithValue("@responsavel", item.Responsavel);
            comando.ExecuteNonQuery();
        }

        // MÉTODO 5 — DELETE pela chave primária.
        public void Excluir(int matricula)
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = "DELETE FROM Aluno WHERE Matricula = @matricula;";
            comando.Parameters.AddWithValue("@matricula", matricula);
            comando.ExecuteNonQuery();
        }

        // MÉTODO 6 — Consulta de um único registro; retorna null se não existir.
        public Aluno ObterPorMatricula(int matricula)
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT Matricula, Nome, Turma, Serie, Responsavel
                  FROM Aluno
                 WHERE Matricula = @matricula;
            ";
            comando.Parameters.AddWithValue("@matricula", matricula);

            using var reader = comando.ExecuteReader();
            if (reader.Read())
            {
                return MontarAluno(reader);
            }
            return null;
        }

        // MÉTODO 7 — Carrega TODOS os registros do banco para uma List<Aluno> em memória.
        // É este método que alimenta a estrutura de dados usada na paginação.
        public List<Aluno> ObterTodos()
        {
            List<Aluno> lista = new List<Aluno>();

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT Matricula, Nome, Turma, Serie, Responsavel
                  FROM Aluno
                 ORDER BY Nome;
            ";

            using var reader = comando.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(MontarAluno(reader)); // Add no final da lista: O(1) amortizado
            }
            return lista;
        }

        // MÉTODO 8 — Conta quantos registros existem (usado para saber se precisa popular).
        public int ContarRegistros()
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = "SELECT COUNT(*) FROM Aluno;";
            return Convert.ToInt32(comando.ExecuteScalar());
        }

        // MÉTODO 9 — "Upsert": evita erro de chave primária duplicada ao repopular o banco.
        public void InserirOuAtualizar(Aluno item)
        {
            var existente = ObterPorMatricula(item.Matricula);

            if (existente == null)
                Inserir(item);
            else
                Atualizar(item);
        }

        // MÉTODO 10 — Converte uma linha do SqliteDataReader em um objeto Aluno.
        private static Aluno MontarAluno(SqliteDataReader reader)
        {
            return new Aluno(
                reader.GetInt32(0),
                reader.GetString(1),
                reader.GetString(2),
                reader.GetString(3),
                reader.GetString(4)
            );
        }
    }
}
