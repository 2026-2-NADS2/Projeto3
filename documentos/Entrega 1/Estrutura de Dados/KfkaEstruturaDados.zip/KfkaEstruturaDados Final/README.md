# KFKA — Entrega 1 de Estrutura de Dados

Projeto Interdisciplinar — 2º ADS — 2º semestre 2026
Aplicação console em C# que simula a **paginação de alunos** utilizando uma
`List<Aluno>` populada a partir de um banco de dados relacional **SQLite**.

## Requisitos

- .NET SDK 8.0 ou superior
- Pacote `Microsoft.Data.Sqlite` (já referenciado no `.csproj`)

## Como rodar

```bash
dotnet restore
dotnet run
```

Na primeira execução o arquivo `alunos.db` é criado automaticamente e populado
com 24 alunos fictícios. Nas execuções seguintes os dados já existentes são
reaproveitados.

## Comandos da aplicação

| Tecla | Ação |
|-------|------|
| P | Próxima página |
| A | Página anterior |
| I | Ir para uma página específica |
| B | Buscar aluno por matrícula |
| S | Sair |

## Estrutura do banco

Tabela `Aluno`:

| Coluna | Tipo | Observação |
|--------|------|------------|
| Matricula | INTEGER | Chave primária |
| Nome | TEXT | Não nulo |
| Turma | TEXT | Não nulo |
| Serie | TEXT | Não nulo |
| Responsavel | TEXT | Não nulo |

## Estrutura de arquivos

- `Aluno.cs` — TAD (Tipo Abstrato de Dados) que representa o aluno.
- `AlunoDB.cs` — classe de acesso a dados; encapsula o SQL e devolve objetos.
- `Program.cs` — orquestra o fluxo e implementa a paginação.

## Conceitos de Estrutura de Dados aplicados

- **Coleção dinâmica (`List<Aluno>`)**: os registros são carregados uma única vez
  do banco e mantidos em memória; `Add` no final tem custo O(1) amortizado.
- **Acesso por índice**: a exibição de cada página usa `alunos[i]`, com custo O(1)
  por elemento, percorrendo apenas a faixa da página.
- **Paginação manual**: o índice inicial é calculado como `(pagina - 1) * TamanhoPagina`
  e o final é limitado por `Math.Min(...)` para não ultrapassar o tamanho da lista.
  O total de páginas usa divisão inteira arredondada para cima.
- **Busca sequencial**: percorre a lista comparando a matrícula, com custo O(N) no
  pior caso e O(1) no melhor caso.
- **Separação de responsabilidades**: o acesso ao banco fica isolado no repositório,
  e a manipulação da estrutura de dados fica no `Program.cs`.
